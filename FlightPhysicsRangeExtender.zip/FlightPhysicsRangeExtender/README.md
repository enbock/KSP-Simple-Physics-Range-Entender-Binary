# PhysicsRangeExtender
This is a KSP mod based on a piece of code written by BahamutoD for BDArmory and improved by myself.

Basically it extends game physics range(1)! This will allow you to switch between vessel that are far away or even to see an orbital station from a flying plane.

(1) This mod allows to extended the physics range but it will not prevent the consecuences of doing it.

You might experience some of the following effects when the range is extended > 100 km: vessel shaking, lights flickering, phatom forces, landed vessels colliding with the ground, etc.
